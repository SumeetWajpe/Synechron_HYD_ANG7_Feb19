export class Post{
    constructor(public id?:number,
        public userId?:number,
        public title?:string,
        public body?:string){

    }
}
// OR
// export class Postt{
//     public id:number;
//         public userId:number;
//         public title:string;
//         public body:string;

//         constructor(id:number,userId:number,title:string,body:string){
//                 this.id = id;
//                 this.body = body;
//         }
// }