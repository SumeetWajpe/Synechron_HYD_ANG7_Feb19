import { Directive, ElementRef, Input, HostListener,Renderer2 } from '@angular/core';

@Directive({
    selector:`[highlight]`
})
export class HighlightDirective{
      @Input() bgcolor:string="lightyellow";
        constructor(private eleRef:ElementRef,
            private renderObj:Renderer2){ }
        ngOnInit(){
            this.eleRef.nativeElement.style.border = "2px solid red";
            this.eleRef.nativeElement.style.backgroundColor = this.bgcolor;
            this.eleRef.nativeElement.style.borderRadius = "5px";
            this.eleRef.nativeElement.style.margin = "5px";
            this.eleRef.nativeElement.style.padding = "5px";
        }

       @HostListener('mouseenter')  On_Mouse_Enter_Handler(){
            this.eleRef.nativeElement.style.backgroundColor = "orange";
            this.eleRef.nativeElement.style.cursor = "pointer";
            var div = this.renderObj.createElement('div');
            var text =this.renderObj.createText("Hovered !");
            this.renderObj.appendChild(div,text);
            this.renderObj.appendChild(this.eleRef.nativeElement,div)
        }
        @HostListener('mouseleave') On_Mouse_Out_Handler(){
            this.eleRef.nativeElement.style.backgroundColor = this.bgcolor;
        }
}