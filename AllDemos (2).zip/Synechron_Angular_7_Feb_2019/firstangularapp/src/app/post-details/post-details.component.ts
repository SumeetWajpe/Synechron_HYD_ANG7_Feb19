import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../posts/posts.service';
import { Post } from '../posts/post.model';

@Component({
  selector: 'app-post-details',
  templateUrl: './post-details.component.html',
  styleUrls: ['./post-details.component.css']
})
export class PostDetailsComponent implements OnInit {

  thePostId:number;
  thecurrPost:Post = new Post();
  constructor(public currRoute:ActivatedRoute,
    public postServObj:PostsService) { }

  ngOnInit() {
    this.currRoute.params.subscribe(
      p=>{
        this.thePostId = p['id'];
       this.thecurrPost = this.postServObj.listofposts.find(
         currPost=> currPost.id == this.thePostId
       );
      }
    )
  }

}
