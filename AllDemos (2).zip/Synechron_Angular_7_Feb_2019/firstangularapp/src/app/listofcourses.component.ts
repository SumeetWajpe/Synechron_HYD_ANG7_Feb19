import {Component} from '@angular/core';
import { Course } from './course.model';
import { CourseService } from './course.service';


@Component({
    selector:`app-list-of-course`,
   templateUrl:`./listofcourses.template.html`,
   styleUrls:['./listofcourses.style.css'],
   providers:[CourseService]
})
export class ListOfCoursesComponent{

    headerimageUrl:string = "https://lh3.googleusercontent.com/OGLQfiHRBZFJh35FESlW69RHryUJ0edszXy02rwDs6ntO615GB5Gen0ApmVju_-xE3o";
    heading:string="List Of All Courses ";
    companyName:string="";
    courseToBeSearched:string="";
    newCourse:Course = new Course();
    courses:Course[] = [];

    
    constructor(private servObj:CourseService) {
        this.courses = this.servObj.getAllCourses();
    }

    ChangeHeading(){
        this.heading = "Udemy !";
    }
    AddNewCourse(theForm){
        //?? add a new course?

        if(theForm.valid){
            this.courses.push(this.newCourse);
            this.newCourse = new Course(); //clears the form !
            theForm.reset();
        }
      
    }
    
}
