
export class ProductService{
    listOfProducts:string[] = ['Shoes','LED TV','Mobile'];
    getAllProducts():string[]{
            return this.listOfProducts;
    }

    AddNewProduct(productToBeAdded:string){
            this.listOfProducts.push(productToBeAdded);
            console.log(this.listOfProducts);
    }
}