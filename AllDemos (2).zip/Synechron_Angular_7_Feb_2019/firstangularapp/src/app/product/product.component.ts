import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
  // providers:[ProductService]
})
export class ProductComponent implements OnInit {
  newProduct:string="";
  constructor(public servObj:ProductService) { }

  ngOnInit() {
  }

  AddProduct(){
    
    this.servObj.AddNewProduct(this.newProduct)
  }

}
