import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChildoflifecycleComponent } from './childoflifecycle.component';

describe('ChildoflifecycleComponent', () => {
  let component: ChildoflifecycleComponent;
  let fixture: ComponentFixture<ChildoflifecycleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChildoflifecycleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChildoflifecycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
