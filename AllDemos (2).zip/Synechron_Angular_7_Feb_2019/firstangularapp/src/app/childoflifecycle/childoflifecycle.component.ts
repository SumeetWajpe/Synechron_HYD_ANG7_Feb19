import { Component, OnInit, OnChanges, Input, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-childoflifecycle',
  templateUrl: './childoflifecycle.component.html',
  styleUrls: ['./childoflifecycle.component.css']
})
export class ChildoflifecycleComponent implements OnInit,OnChanges {
@Input() message:string="";

  constructor() {
    console.log('Inside Constructor ! Message : ' + this.message );
   }

  ngOnInit() {
    console.log('Inside ngOnInit ! Message : ' + this.message);
  }

  ngOnChanges(theChanges:SimpleChanges){
    console.log('Inside ngOnChanges ! Message :' + this.message);

    for(let prop in theChanges){
      console.log(`Current Value : ${theChanges[prop].currentValue}, Previous Value : ${theChanges[prop].previousValue}`)
    }

  }
  


}
