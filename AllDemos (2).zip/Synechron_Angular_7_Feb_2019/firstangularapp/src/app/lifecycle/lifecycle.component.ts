import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lifecycle',
  templateUrl: './lifecycle.component.html',
  styleUrls: ['./lifecycle.component.css']
})
export class LifecycleComponent {

  theMessage:string ="";
  constructor() {
    //console.log('Inside Constructor !');
   }

  ngOnInit() {
    //console.log('Inside ngOnInit !');
  }

  

}
