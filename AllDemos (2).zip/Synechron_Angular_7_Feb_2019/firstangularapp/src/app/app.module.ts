import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {Routes,RouterModule} from'@angular/router';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatCheckboxModule} from '@angular/material';

import { AppComponent } from './app.component';
import {ListOfCoursesComponent} from './listofcourses.component';
import {CourseComponent} from './course.component';
import { DurationpipePipe } from './durationpipe.pipe';
import { ProductComponent } from './product/product.component';
import { ProductService } from './product/product.service';
import { PostsComponent } from './posts/posts.component';
import { PostDetailsComponent } from './post-details/post-details.component';
import { HighlightDirective } from './highlight.directive';
import { LifecycleComponent } from './lifecycle/lifecycle.component';
import { ChildoflifecycleComponent } from './childoflifecycle/childoflifecycle.component';


var routes:Routes = [
  {path:'',component:ListOfCoursesComponent},
{path:'posts',component:PostsComponent},
{path:'products',component:ProductComponent},
{path:'lifecycle',component:LifecycleComponent},
{path:'postdetails/:id',component:PostDetailsComponent},
{path:'**',redirectTo:'/posts'}
];

@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    ListOfCoursesComponent,
    DurationpipePipe,
    ProductComponent,
    PostsComponent,
    PostDetailsComponent,
    HighlightDirective,
    LifecycleComponent,
    ChildoflifecycleComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes),
    BrowserAnimationsModule,
    MatCheckboxModule
  ],
  providers:[ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }

