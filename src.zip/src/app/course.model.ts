export class Course{
    constructor(
        public name?:string,
        public duration?:string,
        public price?:number,
        public rating?:number,
        public trainer?:string,
        public imageUrl?:string
        ){

    }
}