import {Component} from '@angular/core';
import { Course } from './course.model';


@Component({
    selector:`app-list-of-course`,
   templateUrl:`./listofcourses.template.html`
})
export default class ListOfCoursesComponent{

    headerimageUrl:string = "https://lh3.googleusercontent.com/OGLQfiHRBZFJh35FESlW69RHryUJ0edszXy02rwDs6ntO615GB5Gen0ApmVju_-xE3o";
    heading:string="List Of All Courses ";
    companyName:string="";
    courses:Course[] = [
        new Course("Node","3  Days",5000,4,"Manish","https://d2eip9sf3oo6c2.cloudfront.net/tags/images/000/000/256/full/nodejslogo.png"),
      new Course("Angular",'4 Days',5000,4,"Sumeet","https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/250px-Angular_full_color_logo.svg.png"),
      new Course("React",'3 Days',8000,3,"Mahesh","https://cdn-images-1.medium.com/max/2000/1*kt9otqHk14BZIMNruiG0BA.png"),
      new Course("Redux",'2 Days',3000,3,"Abhijeet","https://cdn-images-1.medium.com/max/1600/1*BpaqVMW2RjQAg9cFHcX1pw.png"),
      new Course(".NET",'3 Days',4000,3,"Praveen","https://www.verisign.com/en_IN/resources/img/VRSN_SocialShare-net-Logo_201712.png")
    ];

    ChangeHeading(){
        this.heading = "Udemy !";
    }
    
}
