import {Component} from '@angular/core';
import { Course } from './course.model';


@Component({
    selector:`app-list-of-course`,
    template:`
    <h1> List Of All Courses </h1>
  <p *ngFor="let c of courses">
    <app-course [coursedetails]="c"></app-course>
  </p>
    `
})
export default class ListOfCoursesComponent{
    courses:Course[] = [
        new Course("Node","3  Days",4,"Manish"),
      new Course("Vue",'4 Days',4,"Sumeet"),
      new Course("React",'3 Days',3,"Mahesh")];
    
}
