import {Component, Input} from '@angular/core';
import { Course } from './course.model';


@Component({
    selector:`app-course`,
    templateUrl:`./course.template.html`
   ,styleUrls:['./course.style.css']
})
export default class CourseComponent{
      @Input()   coursedetails:Course = new Course();
      isHighlighted:boolean=false;
      isFree:boolean=false;
}

export function Add(x,y){
    return x + y;
}