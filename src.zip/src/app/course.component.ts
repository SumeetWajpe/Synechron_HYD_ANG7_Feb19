import {Component, Input} from '@angular/core';
import { Course } from './course.model';


@Component({
    selector:`app-course`,
    template:`<h1> {{coursedetails.name}} ! </h1>
    <b> Duration : </b> {{coursedetails.duration}}<br/>
    <b> Rating : </b> {{coursedetails.rating}}<br/>
    <b> Trainer : </b> {{coursedetails.trainer}}<br/>

    `
})
export default class CourseComponent{
      @Input()   coursedetails:Course = new Course();
}

export function Add(x,y){
    return x + y;
}