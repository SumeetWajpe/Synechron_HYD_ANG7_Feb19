import { Component } from '@angular/core';
import { Course } from './course.model';

@Component({
  selector: 'app-root',
  template:`
        <app-list-of-course></app-list-of-course>
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'firstangularapp';  
}
