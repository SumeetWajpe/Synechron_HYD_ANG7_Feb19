import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  template:`
        <app-list-of-course></app-list-of-course>
  `,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'firstangularapp';  
}
