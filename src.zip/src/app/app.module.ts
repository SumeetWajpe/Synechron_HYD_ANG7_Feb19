import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { AppComponent } from './app.component';
import ListOfCoursesComponent from './listofcourses.component';
import CourseComponent from './course.component';
import { DurationpipePipe } from './durationpipe.pipe';

@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    ListOfCoursesComponent,
    DurationpipePipe
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

