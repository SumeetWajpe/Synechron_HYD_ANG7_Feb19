import { DurationpipePipe } from './durationpipe.pipe';

describe('DurationpipePipe', () => {
  it('create an instance', () => {
    const pipe = new DurationpipePipe();
    expect(pipe).toBeTruthy();
  });
});
